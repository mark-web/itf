window.onload = function() {

	var box = new InfoBox();
};
