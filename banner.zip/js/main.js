window.onload = function() {

	var firstBanner = new Banner();
};
