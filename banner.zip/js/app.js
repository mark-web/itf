;(function(){
/*
    Модуль "Банер"
*/
	"use strict";

    var defaults = {
            "mainContainerSelector": ".content",
            "mainContainerSelector": ".content",
            "countRotateSpriteImages": 58,
            "rotateBlockImgSrc" : 'images/phone/',
            "refVideoForRotateBlock": "9xKR8Vcjias",
        },
        mainContainer = null;

	function App (config) {
        var self = this;
        defaults = __extend(defaults, config);
        self.init(defaults.mainContainerSelector);
	}

    //initialization module
    App.prototype.init = function (parentSelector) {
        mainContainer = document.querySelector(parentSelector);
        this.createBox();
        this.addEvents();
    };

    //create and fill box
    App.prototype.createBox = function () {
        
        var sideBlock,
            parentBlock,
            block;        

        //LEFT SIDE
        sideBlock = __createElement('div', {
            'class': 'left',
            'id': 'left'
        });

        //append "logo"
        parentBlock = __createElement('div', {
            'class': 'logo'
        });

        parentBlock.appendChild(
             __createElement('p', {
                    'class': 'logo-top'
            })
        ); 

        parentBlock.appendChild(
             __createElement('p', {
                    'class': 'logo-bottom'
            })
        );        
        
        sideBlock.appendChild(parentBlock);

        //append "description"
        parentBlock = __createElement('div', {
            'class': 'description'
        });

            //block "text1"
            block = __createElement('div', {
                'class': 'text1'
            });

            block.appendChild(
                 __createElement('p', {
                        'class': 'first-row'
                })
            ); 

            block.appendChild(
                 __createElement('p', {
                        'class': 'second-row'
                })
            ); 

        parentBlock.appendChild(block);

            //block "text2"
            block = __createElement('div', {
                'class': 'text2 hide'
            });

            block.appendChild(
                 __createElement('p', {
                        'class': 'first-row'
                })
            ); 

            block.appendChild(
                 __createElement('p', {
                        'class': 'second-row'
                })
            );

            block.appendChild(
                 __createElement('p', {
                        'class': 'third-row'
                })
            ); 

        parentBlock.appendChild(block);

            //block "text3"
            block = __createElement('div', {
                'class': 'text3 hide'
            });

            block.appendChild(
                 __createElement('p', {
                        'class': 'first-row'
                })
            ); 

            block.appendChild(
                 __createElement('p', {
                        'class': 'second-row'
                })
            );

            block.appendChild(
                 __createElement('p', {
                        'class': 'third-row'
                })
            ); 

        parentBlock.appendChild(block);   

            //block "text4"
            block = __createElement('div', {
                'class': 'text4 hide'
            });

            block.appendChild(
                 __createElement('p', {
                        'class': 'first-row'
                })
            ); 

            block.appendChild(
                 __createElement('p', {
                        'class': 'second-row'
                })
            );

            block.appendChild(
                 __createElement('p', {
                        'class': 'third-row'
                })
            ); 

        parentBlock.appendChild(block); 


        sideBlock.appendChild(parentBlock);                 
        mainContainer.appendChild(sideBlock);      

        //ROTATE SIDE
        sideBlock = __createElement('div', {
            'class': 'wrap-rotate-block',
            'id': 'wrap-rotate-block'
        });

        //append "rotate-block"
        //реализация ротации через CSS backgroundPosition
     /*   sideBlock.appendChild(
             __createElement('div', {
            'class': 'rotate-block'
            })
        );*/
        sideBlock.appendChild(
             __createElement('img', {
            'class': 'rotate-block hide',
            'src': defaults.rotateBlockImgSrc + 'phone_00000.png'
            })
        );

        sideBlock.appendChild(
             __createElement('div', {
            'class': 'video-block rotate-block',
            'text': '<iframe width="495" height="220" src="https://www.youtube.com/embed/' + 
                    defaults.refVideoForRotateBlock + 
                    '?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>'
            })
        );

        sideBlock.appendChild(
             __createElement('div', {
            'class': 'flash'
            })
        );

        sideBlock.appendChild(
             __createElement('div', {
            'class': 'rain-container'
            })
        );
                   
        mainContainer.appendChild(sideBlock); 

        //DRAGBAR BLOCK
        sideBlock = __createElement('div', {
            'class': 'dragbar',
            'id': 'dragbar'
        });

        //append "rotate-block"
        sideBlock.appendChild(
             __createElement('div', {
            'class': 'ball'
            })
        );
                   
        mainContainer.appendChild(sideBlock); 

        //RIGHT BLOCK
        sideBlock = __createElement('div', {
            'class': 'right',
            'id': 'right'
        });

            //block "close"
            block = __createElement('div', {
                'class': 'close'
            });

            block.appendChild(
                 __createElement('span', {
                        'text': 'Close Ad'
                })
            ); 

            block.appendChild(
                 __createElement('img', {
                        'class': 'close-img',
                        'alt': 'Close Ad',
                        'src': '../images/close_black.png'
                })
            ); 

        sideBlock.appendChild(block);                     

            //block "help"
            block = __createElement('div', {
                'class': 'help'
            });

            block.appendChild(
                 __createElement('p', {
                        'class': 'first-row'
                })
            ); 

            block.appendChild(
                 __createElement('p', {
                        'class': 'second-row'
                })
            );
                   
        sideBlock.appendChild(block);                     

        sideBlock.appendChild(
             __createElement('button', {
                    'class': 'buy-btn'
            })
        ); 

        mainContainer.appendChild(sideBlock);                     

    };

//реализация ротации через CSS backgroundPosition
/*  
    App.prototype.rotateMainContent = function (bollTopCoord, dragbarHeight) {
        
        var rotateBlock = mainContainer.querySelector('.rotate-block'),
            rotateBlockHeight = rotateBlock.offsetHeight,
            imgNumber = Math.round((bollTopCoord*defaults.countRotateSpriteImages)/dragbarHeight);   

            rotateBlock.style.backgroundPosition = '0 -' + imgNumber*220 + 'px';
    }
*/

    //ИЗМЕНИЛ РЕАЛИЗАЦИЮ ЧЕРЕЗ SRC т.к. в спрайте не равномерное смещение изображений(не везде 220px)
    App.prototype.rotateMainContent = function (bollTopCoord, dragbarHeight) {
        
        var rotateBlock = mainContainer.querySelector('.rotate-block'),
            rotateBlockHeight = rotateBlock.offsetHeight,
            imgNumber = Math.round((bollTopCoord*defaults.countRotateSpriteImages)/dragbarHeight),
            imgNumberStr = '00000';   

        rotateBlock.src = defaults.rotateBlockImgSrc + 'phone_' + imgNumberStr.slice(0,'-'+String(imgNumber).length) + imgNumber + ".png";           
        this.rotateDescriptionText(imgNumber);
        this.showFlash(imgNumber);
    }

    //ротация description > text
    App.prototype.rotateDescriptionText = function (currentSlideNumber) {
        
        var rotateBlock = mainContainer.querySelector('.description'),            
            totalTextNumbers = rotateBlock.children.length,
            dataRange = Math.round(defaults.countRotateSpriteImages/totalTextNumbers),
            elementNumberToShow,
            textElement,
            i;  

        for (i = 0; i < 4; i++) {

            if (!__hasClass(rotateBlock.children[i], 'hide')) {
                __addClass(rotateBlock.children[i], 'hide');
            }

            if (
                currentSlideNumber >= dataRange * i
                && currentSlideNumber < dataRange * (i + 1)
            ) {
                __removeClass(rotateBlock.children[i], 'hide');
            }
        }
    }  

    //отображение вспышки
    App.prototype.showFlash = function (currentSlideNumber) {

        var el = mainContainer.querySelector('.flash'),
            i = 0,
            duration = 500;

        if (Number(currentSlideNumber) == 30) {
                         
           //fade_in
            for (i; i <= 1; i += 0.01) {
                (function(){
                    var myI = i;
                    window.setTimeout( function () {
                        __setFlashOpacity(el, myI);  
                        el.style.height = Number(50*myI*10) + 'px';
                        el.style.width = Number(50*myI*10) + 'px';                     
                    }, i * duration);                         
                })();
            }

            //fade_out
            for (i; i <= 2; i += 0.01) {
                (function(){
                    var myI = i;
                    window.setTimeout( function () {
                        __setFlashOpacity(el, (2 - myI));     
                        el.style.height = Number(50*myI*10) + 'px';
                        el.style.width = Number(50*myI*10) + 'px';  
                    }, i * duration); 
                })();       
            }
        }
    }       

    App.prototype.addEvents = function () {
        var self = this,
            descriptionText,
            descriptionBlock = mainContainer.querySelector('.description'),            
            rotateBlock      = mainContainer.querySelector('.rotate-block'),
            videoBlock      = mainContainer.querySelector('.video-block'),
            dragbar          = mainContainer.querySelector('.dragbar'),
            ball             = dragbar.querySelector('.ball'),
            buyBtn           = mainContainer.querySelector('.buy-btn'),
            closeBtn         = mainContainer.querySelector('.close');

        //boll move block
          ball.onmousedown = function(e) {
            var ballCoords = __getCoords(ball),
                shiftY = e.pageY - ballCoords.top, 
                parentsCoords = __getCoords(dragbar);

            if (__hasClass(rotateBlock, 'hide')) {
                __addClass(videoBlock, 'hide');
                __removeClass(rotateBlock, 'hide');
            }    

            document.onmousemove = function(e) {   

                  //  вычесть координату родителя, т.к. position: relative
                var newTop = e.pageY - shiftY - parentsCoords.top,                
                    bottomEdge = dragbar.offsetHeight  - ball.offsetHeight ;

                  // если курсор ушёл вне блока
                if (newTop < 0) {
                    newTop = 0;
                }
               
                if (newTop > bottomEdge) {
                    newTop = bottomEdge;
                }

                ball.style.top = newTop + 'px';

                self.rotateMainContent(newTop, bottomEdge);
            }

            document.onmouseup = function() {
                document.onmousemove = document.onmouseup = null;
            };

            return false; // disable selection start (cursor change)
          };

          ball.ondragstart = function() {
            return false;
          };
        //END boll move block

        //buy button click
        __addEvent('click', buyBtn, function () {
            alert('Thanks for buy product!');
            __addClass(mainContainer, 'hide');
        });

        //close banner
        __addEvent('click', closeBtn, function () {
            __addClass(mainContainer, 'hide');
        });

    }; 
  

    //for creating composite/custom DOM element
    var __createElement = function (name, attributes) {
        var element = document.createElement(name),
            i;

        if (typeof attributes == 'object') {
            for (i in attributes) {
                if( i.toLowerCase() == 'text') {
                    element.innerHTML = attributes.text;
                }else {
                    element.setAttribute(i, attributes[i]);
                }

                if ( i.toLowerCase() == 'class' ) {
                    element.className = attributes[i];

                } else if ( i.toLowerCase() == 'style' ) {
                    element.style.cssText = attributes[i];
                }
            }
        }

        return element;
    }

    //helper private functions

    //function-helper for extend two in one
    function __extend(mainObj, userObj){

        if (userObj != undefined) {
            for (var i in mainObj) {
                if (userObj[i] != undefined) {
                    mainObj[i] = userObj[i];
                }
            }
        }
        return mainObj;
    }


    function __removeClass (element, classNameForRemove) {
        var classes = element.className.split(' ');

        for (var i = 0; i < classes.length; i++) {
            if (classes[i] == classNameForRemove) {
                classes.splice(i, 1); // удалить класс
                i--;
            }
        }
        element.className = classes.join(' ');

        return element;
    }

    function __addClass (element, classNameForAdd) {
        var classes = element.className ? element.className.split(' ') : [];

        for (var i = 0; i < classes.length; i++) {
            if (classes[i] == classNameForAdd) return;
        }
        classes.push(classNameForAdd);
        element.className = classes.join(' ');

        return element;
    }

    function __addEvent (evnt, elem, func) {
        if (elem.addEventListener)
            elem.addEventListener(evnt,func,false);
        else if (elem.attachEvent) {
            elem.attachEvent("on"+evnt, func);
        }
        else {
            elem[evnt] = func;
        }
    }

    function __hasClass(el, cls) {
        return el.className && new RegExp("(\\s|^)" + cls + "(\\s|$)").test(el.className);
    }

    function __round (number) {         
        return Math.round(number*100)/100;
    }

      // передвинуть мяч под координаты курсора
  // и сдвинуть на половину ширины/высоты для центрирования
  function __moveElement(e, element) {

    var coords = __getCoords(element),
        shiftX = e.pageX - coords.left,
        shiftY = e.pageY - coords.top;

    element.style.left = e.pageX + 'px';
    element.style.top = e.pageY + 'px';
  }

  function __getCoords(elem) {
      // (1)
      var box = elem.getBoundingClientRect();

      var body = document.body;
      var docEl = document.documentElement;

      // (2)
      var scrollTop = window.pageYOffset || docEl.scrollTop || body.scrollTop;
      var scrollLeft = window.pageXOffset || docEl.scrollLeft || body.scrollLeft;

      // (3)
      var clientTop = docEl.clientTop || body.clientTop || 0;
      var clientLeft = docEl.clientLeft || body.clientLeft || 0;

      // (4)
      var top = box.top + scrollTop - clientTop;
      var left = box.left + scrollLeft - clientLeft;

      return {
        top: top,
        left: left
      };
    }

    function __setFlashOpacity (el, op) {
        el.style.opacity = op.toString();
        el.style.MozOpacity = op.toString();
        el.style.KhtmlOpacity = op.toString();
        el.style.filter = 'alpha(opacity=' + (op * 100).toString() + ')';        
    };

    window.Banner = App;

    return App;
}());
