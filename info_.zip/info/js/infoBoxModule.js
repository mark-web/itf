;(function($){

	"use strict";

    var defaults = {
            "contentUrl": "info_box.json",
            "boxContainer": ".content",
            "prevBtn" : [
                {
                    "id" :"prevBtn",
                    "text" :"Prev",
                    "style" : "",
                    "class" : "btn prevBtn"
                }
            ],
            "nextBtn" : [
                {
                    "id" :"nextBtn",
                    "text" :"Next",
                    "style" : "",
                    "class" : "btn nextBtn"
                }
            ],
            "prevArrow" : [
                {
                    "style" : "",
                    "class" : "prevArrow"
                }
            ],
            "nextArrow" : [
                {
                    "style" : "",
                    "class" : "nextArrow"
                }
            ],
            detailsTextHide : 'hide details',
            detailsTextShow : 'show details'
        },
        content,
        mainContainer = null,
        visibleSlideNumber = 0,
        slides,
        contentUrl;

	function App (config) {
        var self = this;
        defaults = __extend(defaults, config);

		contentUrl = defaults.contentUrl;

        $.getJSON(contentUrl, function(data) {
            content = data;
            self.init(defaults.boxContainer);
        });
	}

    //initialization module
    App.prototype.init = function (parentSelector) {
        mainContainer = document.querySelector(parentSelector);
        this.createBox();
        this.addEvents();
    };

    //create and fill info-box
    App.prototype.createBox = function () {
        //main block
        var i,
            slide,
            slideContent,
            sliderContainer = __createElement('div', {
                'class': 'sliderContainer'
            }),
            slidersCollection = __createElement('div', {
                'class': 'slidersCollection'
            }),
            slider = __createElement('ul', {
                class: 'slider '
            }),
            slideContentBox = null,
            wrapper = null,
            imgContainer = null,
            img = null,
            slideHeader = null,
            slideDescription = null,
            details = null,
            detailsLink = null;

        mainContainer.appendChild(sliderContainer);
        sliderContainer.appendChild(slidersCollection);
        slidersCollection.appendChild(slider);

        for (i in content) {
            slide = __createElement('li', {
                class : 'slide'
            });
            imgContainer = __createElement('div', {
                class : 'imgContainer'
            });
            img = __createElement('img', {
                src : 'img/' + content[i].img
            });
            slideContent = __createElement('div', {
                class : 'slideContent'
            });
            slideHeader = __createElement('div', {
                class : 'slideHeader',
                text : content[i].title
            });
            slideContentBox = __createElement('div', {
                class : 'slideContentBox'
            });
            slideDescription = __createElement('div', {
                class : 'slideDescription',
                text : content[i].description
            });
            details = __createElement('div', {
                class : 'details',
                text : content[i].note
            })
            detailsLink = __createElement('a', {
                class : 'detailsLink',
                text : defaults.detailsTextShow
            });

            slider.appendChild(slide);
            slide.appendChild(imgContainer);
            imgContainer.appendChild(img);
            slide.appendChild(slideContent);
            slideContent.appendChild(slideHeader);
            slideContent.appendChild(slideContentBox);
            slideContentBox.appendChild(slideDescription);
            slideContentBox.appendChild(details);
            slideContent.appendChild(detailsLink);

            slideContent.style.top = '0px';
        }

        //slider footer buttons panel
        var buttonsPanel = __createElement('div', {
                class : 'buttonsPanel'
            }),
            prevBtn = null,
            nextBtn = null,
            prevArrow = null,
            nextArrow = null;

        for (i in defaults.prevBtn) {
            prevBtn = __createElement('div', {
                id : defaults.prevBtn[i].id,
                class : defaults.prevBtn[i].class,
                text : defaults.prevBtn[i].text,
                style : defaults.prevBtn[i].style
            });
        }
        for (i in defaults.nextBtn) {
            nextBtn = __createElement('div', {
                id : defaults.nextBtn[i].id,
                class : defaults.nextBtn[i].class,
                text : defaults.nextBtn[i].text,
                style : defaults.nextBtn[i].style
            });
        }
        for (i in defaults.prevArrow) {
            prevArrow = __createElement('div', {
                id : 'prevArrow',
                class : 'prevArrow control',
                style : defaults.prevArrow[i].style
            });
        }
        for (i in defaults.nextArrow) {
            nextArrow = __createElement('div', {
                id : 'nextArrow',
                class : 'nextArrow control',
                style : defaults.nextArrow[i].style
            });
        }

        sliderContainer.appendChild(buttonsPanel);
        buttonsPanel.appendChild(prevBtn);
        buttonsPanel.appendChild(nextBtn);
        prevBtn.appendChild(prevArrow);
        nextBtn.appendChild(nextArrow);

        this.showSlide();
    };

    App.prototype.showSlide = function() {
        if (!visibleSlideNumber || visibleSlideNumber<0) {
            visibleSlideNumber = 0;
        }
        //slides = mainContainer.getElementsByClassName('slide'),
        slides = mainContainer.getElementsByClassName('slide');

        __addClass(slides[visibleSlideNumber], 'visibleSlide');
    }

    App.prototype.showNextSlide = function() {
        visibleSlideNumber++;
        slides = mainContainer.getElementsByClassName('slide');
        if (visibleSlideNumber >= slides.length) {
            visibleSlideNumber = 0;
        }
        __removeClass(mainContainer.querySelector('.visibleSlide'), 'visibleSlide');
        this.showSlide();
    }

    App.prototype.showPrevSlide = function() {
        visibleSlideNumber--;

        if (visibleSlideNumber < 0) {
            slides = mainContainer.getElementsByClassName('slide');
            visibleSlideNumber = slides.length-1;
        }
        __removeClass(mainContainer.querySelector('.visibleSlide'), 'visibleSlide');
        this.showSlide();
    }


    App.prototype.addEvents = function () {
        var self = this,
            prevBtn = mainContainer.querySelector("#prevBtn"),
            nextBtn = mainContainer.querySelector("#nextBtn"),
            detailsLinks = mainContainer.getElementsByClassName('detailsLink'),
            i,
            slideContentBox;

        __addEvent('click', prevBtn, function () {
            self.showPrevSlide();
        });

        __addEvent('click', nextBtn, function () {
            self.showNextSlide();
        });

        for (i in detailsLinks) {

            if (typeof detailsLinks[i] == 'object') {
                slideContentBox = detailsLinks[i].parentNode.parentNode;

                __addEvent('click', detailsLinks[i], function () {
                    self.toggleDetails(this);
                });
            }
        };
    };

    App.prototype.toggleDetails = function (detailsLink) {

        var slideContentainer = detailsLink.parentNode.parentNode,
            slideContent = slideContentainer.querySelector('.slideContent'),
            imgContainer = slideContentainer.querySelector('.imgContainer'),
            detailsLink = slideContentainer.querySelector('.detailsLink'),
            slideContentBox = slideContentainer.querySelector('.slideContentBox');

        if (!__hasClass(imgContainer, 'hidden')) {
            __removeClass(imgContainer, 'visible');
            __addClass(imgContainer, 'hidden');
            __addClass(slideContentBox, 'openedDetails');
            detailsLink.innerHTML = defaults.detailsTextHide;

        } else {
            __addClass(imgContainer, 'visible');
            __removeClass(imgContainer, 'hidden');
            __removeClass(slideContentBox, 'openedDetails');
            detailsLink.innerHTML = defaults.detailsTextShow;
        }
    };

    //helper private functions
    //for creating composite/custom DOM element
    var __createElement = function (name, attributes) {
        var element = document.createElement(name),
            i;

        if (typeof attributes == 'object') {
            for (i in attributes) {
                if( i.toLowerCase() == 'text') {
                    element.innerHTML = attributes.text;
                }else {
                    element.setAttribute(i, attributes[i]);
                }

                if ( i.toLowerCase() == 'class' ) {
                    element.className = attributes[i];

                } else if ( i.toLowerCase() == 'style' ) {
                    element.style.cssText = attributes[i];
                }
            }
        }

        return element;
    }

    //function-helper for extend two in one
    function __extend(mainObj, userObj){

        if (userObj != undefined) {
            for (var i in mainObj) {
                if (userObj[i] != undefined) {
                    mainObj[i] = userObj[i];
                }
            }
        }
        return mainObj;
    }


    function __removeClass (element, classNameForRemove) {
        var classes = element.className.split(' ');

        for (var i = 0; i < classes.length; i++) {
            if (classes[i] == classNameForRemove) {
                classes.splice(i, 1); // удалить класс
                i--;
            }
        }
        element.className = classes.join(' ');

        return element;
    }

    function __addClass (element, classNameForAdd) {
        var classes = element.className ? element.className.split(' ') : [];

        for (var i = 0; i < classes.length; i++) {
            if (classes[i] == classNameForAdd) return;
        }
        classes.push(classNameForAdd);
        element.className = classes.join(' ');

        return element;
    }

    function __addEvent (evnt, elem, func) {
        if (elem.addEventListener)
            elem.addEventListener(evnt,func,false);
        else if (elem.attachEvent) {
            elem.attachEvent("on"+evnt, func);
        }
        else {
            elem[evnt] = func;
        }
    }

    function __hasClass(el, cls) {
        return el.className && new RegExp("(\\s|^)" + cls + "(\\s|$)").test(el.className);
    }

    window.InfoBox = App;

    return App;
}(jQuery));
