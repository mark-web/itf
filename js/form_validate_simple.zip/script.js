"use strict"

$(document).ready(function(){

	$("#regForm").on("submit", function(){
		var result = true;
		var form = $(this);

		$(this).find("[placeholder]").each(function(i){

		result = isEmpty(this);

			if(result){

				switch(this.name){
					case 'fname': result = checkFIO(this); break;
					case 'lname': result = checkFIO(this); break;
					case 'login': result = checkLogin(this); break;
					case 'passwd': result = checkPassword(this); break;
					case 'tel': result = checkTel(this); break;
					case 'email': result = checkEmail(this); break;
				}
			}

		})

			event.preventDefault();						
			//если все проверки успешны - шлём сохранение
		if(result){			
				
				$.post(
				  "/backend/reg.php?reg=on", $("#regForm").serialize()
					, function( response ) {
						console.log(response);
					});
		}

	});


//ДЛЯ БЛУРА
 	var regForm = $("#regForm");

 	regForm.find("[placeholder]").on("blur", function(){
 		
 		var elemValue = $(this).val();

		//если поле пустое - подсвечиваем элемент и добавляем текст ошибки
		var result = isEmpty(this);

			if(result){

				switch(this.name){
					case 'fname': result = checkFIO(this); break;
					case 'lname': result = checkFIO(this); break;
					case 'login': result = checkLogin(this); break;
					case 'passwd': result = checkPassword(this); break;
					case 'tel': result = checkTel(this); break;
					case 'email': result = checkEmail(this); break;
				}
			}
 	});
});


function isEmpty(element){

	var elemValue = $(element).val();
	var result = false;

	//удаляем алерт
	if($(element).next('span').hasClass("alert")){
		$(element).removeClass('alert-border').next('span').remove();
	}

	if(elemValue != '' ){
		result = true;
	}

	if(elemValue == ''){

		$(element).addClass('alert-border')
			.after('<span class="alert">Поле ' + 
				$(element).attr('placeholder') +
				' должно быть заполненным</span>');

	}

	return result;
}


function checkFIO(element){
	
	//если дальше есть алерт - удаляем	
	if($(element).next('span').hasClass("alert")){
		$(element).removeClass('alert-border').next('span').remove();
	}

	var result = $(element).next('span').hasClass("alert");// == false
	var elemValue = $(element).val();



	if (!result 
		&& (elemValue.length < 3 || elemValue.length > 20)) {

		$(element).addClass('alert-border')
			.after('<span class="alert">Поле ' + 
				$(element).attr('placeholder') +
				' должно быть больше 3х и меньше 20и символов </span>');

	 	result = false;
	}

	return result;
}



function checkEmail(element){
	
	//если дальше есть алерт - удаляем	
	if($(element).next('span').hasClass("alert")){
		$(element).removeClass('alert-border').next('span').remove();
	}


	var result = $(element).next('span').hasClass("alert");// == false
	var elemValue = $(element).val(); //"test_com15@inf-1.test.com.ua"
	var needAjax = true;
		
	if (!result 
		&& (elemValue.match(/^[a-z][a-z,_,0-9]{1,20}@[a-z,0-9\-]{1,10}\.[a-z\.]{1,10}[a-z]$/)) == null) {

		$(element).addClass('alert-border')
			.after('<span class="alert">Поле ' + 
				$(element).attr('placeholder') +
				' email должен быть вида test_com15@inf-1.test.com.ua </span>');

	 	result = false;
	 	needAjax = false;
	}

	if(needAjax == true){
		
		$.ajax({
		  url: "/backend/reg.php?check=on&login="+elemValue
		}).done(function(response) {
			
		    if(response == 1){
				
				$(element).addClass('alert-border')
					.after('<span class="alert">Поле ' + $(element).attr('placeholder') +' похоже уже занят  </span>');
				
				result = false;
			}else{
				result = true;
			}

		}).fail(function() {

			$(element).addClass('alert-border')
					.after('<span class="alert">Поле ' + $(element).attr('placeholder') + ' ошибка на сервере </span>');

			result = false;

		}).always(function(response) {

		    return result;

		});
	}

	if(needAjax == false){
		return result;	
	}	
}

//+380(77)777-77-77
function checkTel(element){
	
	//если дальше есть алерт - удаляем	
	if($(element).next('span').hasClass("alert")){
		$(element).removeClass('alert-border').next('span').remove();
	}

	var result = $(element).next('span').hasClass("alert");// == false
	var elemValue = $(element).val(); //"test_com15@inf-1.test.com.ua"
		
	if (!result 
		&& (elemValue.match(/\+380\([5,6,7,9][0-9]\)[0-9]{3}\-[0-9]{2}\-[0-9]{2}/)) == null) {

		$(element).addClass('alert-border')
			.after('<span class="alert">Поле ' + 
				$(element).attr('placeholder') +
				' телефон должен быть вида +380(77)777-77-77 </span>');

	 	result = false;
	}

	return result;
}


function checkPassword(element){
	
	var message = '';

	//если дальше есть алерт - удаляем	
	if($(element).next('span').hasClass("alert")){
		$(element).removeClass('alert-border').next('span').remove();
	}

	var result = $(element).next('span').hasClass("alert");// == false
	var elemValue = $(element).val(); //"test_com15@inf-1.test.com.ua"
		

//РЕГУЛЯРКА ПАРОЛЯ
//требования: 
// 1) должен быть длиной от 8 до 64, 
// 2) должен содержать минимум 1 символ в верхнем регистре
// 3) должен содержать минимум 1 символ в нижнем регистре
// 4) минимум 1 цифра 
// 5) спецсимволы хотябы один: .,/*?$!-

var passLength = elemValue.length;

var passApper = elemValue.match(/[A-Z]/);
var passLower = elemValue.match(/[a-z]/);
var passNumber = elemValue.match(/[0-9]/);
var specialCharacter = elemValue.match(/[\.,\,,\/,\*,\?,\$,\!,\-]/);

	if(passLength< 8 || passLength > 64){
		message += ' Длина НЕ подходит. ';
	}

	if(passApper === null){
		message += ' Должен быть минимум 1 символ в верхнем регистре.';
	}	

	if(passLower === null){
		message += ' Должен быть минимум 1 символ в нижнем регистре.';
	}	
	
	if(passNumber === null){
		message += ' Должен быть минимум 1 цифра.';
	}	

	if(specialCharacter === null){
		message += ' Должен быть минимум 1 спецсимвол.';
	}		
//END РЕГУЛЯРКА ПАРОЛЯ 



	if (!result 
		&& message != '') {

		$(element).addClass('alert-border')
			.after('<span class="alert">Поле ' + 
				$(element).attr('placeholder') +
				message + ' </span>');

	 	result = false;
	}

	return result;
}


function checkLogin(element){
	
	//если дальше есть алерт - удаляем	
	if($(element).next('span').hasClass("alert")){
		$(element).removeClass('alert-border').next('span').remove();
	}

	var result = $(element).next('span').hasClass("alert");// == false
	var elemValue = $(element).val(); //"test_com15@inf-1.test.com.ua"
	var needAjax = true;		

	if (!result 
		&& (elemValue.match(/^[a-zA-Z]{1,10}[a-z,_,0-9]{6,30}$/) == null)) {

		$(element).addClass('alert-border')
			.after('<span class="alert">Поле ' + 
				$(element).attr('placeholder') +
				' логин должен быть [a-zA-Z]{1,10}[a-z,_,0-9]{6,30} </span>');

	 	result = false;
	 	needAjax = false;
	}
	
	if(needAjax == true){
		console.log('TEST');
		console.log(element);
		$.ajax({
		  url: "/backend/reg.php?check=on&login="+elemValue
		}).done(function(response) {
			console.log(element);
		    if(response == 1){
				
				$(element).addClass('alert-border')
					.after('<span class="alert">Поле ' + $(element).attr('placeholder') +' похоже логин уже занят  </span>');
				
				result = false;
			}else{
				result = true;
			}

		}).fail(function() {

			$(element).addClass('alert-border')
					.after('<span class="alert">Поле ' + $(element).attr('placeholder') + ' ошибка на сервере </span>');

			result = false;

		}).always(function(response) {

		    return result;

		});
	}

	if(needAjax == false){
		return result;	
	}	
}


