<?php

function checkData($data, $where){
     foreach ($where as $key => $value) {
        if ($value == $data) {
            echo 1;
            die();
        }
    }
    echo 0;
}

if (isset($_GET["check"]) && $_GET["check"] ) {
    $login = $_GET["login"];
    $eMail = $_GET["email"];
    $userLogins = explode(":",file_get_contents("logins.txt"));
    $userEmails = explode(":",file_get_contents("emails.txt"));
    if ($login) {
        checkData($login, $userLogins);
    }
    if ($eMail) {
        checkData($eMail, $userEmails);
    }
}


if (isset($_GET["reg"]) && $_GET["reg"]) {
   
    if (isset($_REQUEST["login"]) && isset($_REQUEST["passwd"]) &&isset($_REQUEST["fname"]) &&isset($_REQUEST["email"]) &&isset($_REQUEST["tel"])) {
    
        $login = $_REQUEST["login"];
        $email = $_REQUEST["email"];

        file_put_contents("logins.txt", $login.":", FILE_APPEND);
        file_put_contents("emails.txt", $email.":", FILE_APPEND);
        $arr = [];
        foreach ($_REQUEST as $key => $value) {
            if ($_REQUEST[$key] == "reg") {
                continue;
            }

            $arr[$key] = $value;
        }
        file_put_contents("users.txt", serialize($arr)."/:", FILE_APPEND);
        echo "Success";
    }else{
        echo "Error";
    }
}

?>